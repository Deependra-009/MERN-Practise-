import React from 'react';
import ReactDOM from 'react-dom';
import Todolist from './Todolist';

ReactDOM.render(
    <Todolist/>
    ,document.getElementById("root")
);

