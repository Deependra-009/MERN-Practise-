import React, { useState } from 'react';
import AddIcon from '@material-ui/icons/Add';
import { Button } from '@material-ui/core';
import './index.css';
import List from './List';
const Todolist=()=>{
    const [item,setitem]=useState();
    const [newitem,setnewitem]=useState([]);


    const itemEvent=(event)=>{
        setitem(event.target.value);
    }
    const listofitem=()=>{
        setnewitem((previtem)=>{
            return [...previtem,item];
        })
    }
    
    return (
        <>
            <div className='main_div'>
                <div className="center_div">
                    <br/>
                    <h1>ToDo List</h1>
                    <br/>
                    <input onChange={itemEvent}  type="text" placeholder="Add an Item" ></input>
                    <Button onClick={listofitem} className="newBtn">
                        <AddIcon/>
                    </Button>
                    <br/>
                    <ol>
                        {/* <li>{item}</li> */}
                        {
                            newitem.map((val,index)=>{
                            return <List text={val} key={index}></List>
                        })
                        }
                    </ol>
                    <br/>
                </div>
            </div>
        </>
    )

};


export default Todolist;