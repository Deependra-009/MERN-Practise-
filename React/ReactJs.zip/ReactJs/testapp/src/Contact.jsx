import React from 'react'


const Contact=()=>{
    return (
        <h1>Hello I am Contact page</h1>
    )
}

export default Contact;