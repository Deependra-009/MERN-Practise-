import React from 'react';
import {FirstName,LastName} from './App';


const ComponentC = () => {
    return (
        <>
            <FirstName.Consumer>
                {(fname) => {
                    return (
                        <LastName>{(lname)=>{
                            return <h1>my name is {fname}{lname}</h1>
                        }}</LastName>
                    ) 
                }}</FirstName.Consumer>
        </>
    )
}

export default ComponentC;