import React from 'react';
import ComponentB from './ComponentB';
const ComponentA=()=>{
    return <ComponentB></ComponentB>
}

export default ComponentA;