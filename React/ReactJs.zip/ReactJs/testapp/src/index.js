import React from 'react';
import ReactDOM from 'react-dom';
import Card from './Card';
import App from './App';
import {BrowserRouter} from 'react-router-dom';
// import Axios from './Axiox';



// ReactDOM.render(
//     <>
//         <Card></Card>
//         <Card></Card>
//         <Card></Card>
//     </>
//     , document.getElementById('root')
// );
//------------------------------------------------------------------

ReactDOM.render(
    <BrowserRouter>
        <App></App>
    </BrowserRouter>
    ,document.getElementById("root")
);
