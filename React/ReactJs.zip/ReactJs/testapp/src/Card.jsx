import React from 'react';
import img from './Logo.jpg';
import './style.css';



const Card = () => {
    return (
        <>
            <div className="cards">
                <div className="card">
                    <img src={img} alt="mypic" className="card_img"></img>
                    <div className="card_info">
                        <span className="card_category">Netflix Original Series </span>
                        <h3 className="card_title">Dark</h3>
                        <a href="www.google.com" target="_blank">
                            <button>Watch Now</button>
                        </a>
                    </div>
                </div>
            </div>
        </>
    );
};

export default Card;