import React, { useState, useEffect } from 'react';
import Card from './Card';
import Sdata from './Sdata';
// import {Route,Switch} from 'react-router-dom';
// import About from './About';
// import Constact from './Contact';
// import NavBar from './NavBar';
// import User from './User';
// import React, { createContext } from 'react';
// import ComponentA from './ComponentA';

// -------------------------- useContext ---------------------------

// const FirstName=createContext();
// const LastName=createContext();

// const App=()=>{
//     return (
//         <>
//         <FirstName.Provider value={"deepu"}>
//         <LastName.Provider value={"trivedi "}>
//         <ComponentA></ComponentA>
//         </LastName.Provider>
//         </FirstName.Provider>
//         </>
//     )

// }

// export default App;
// export {FirstName,LastName};

//-------------------- use Effect ----------------------------------



// const App=()=>{
//     const [state,setstate]=useState(0);


//     useEffect(()=>{
//         document.title=`you clicked me ${state} times`;
//     })
//     return (
//         <>
//              <button style={{fontSize:'50px'}} onClick={()=>{setstate(state+1)}}>Click me {state}</button>
//         </>
//     )
// }

//---------------------------- React Router ---------------------------------------------------------------


// const App=()=>{
//     return (
//         <>
//             <Switch>
//                 <Route exact path='/' component={About}></Route>
//                 <Route path='/contact' component={Constact}></Route>
//             </Switch>
//             {/* <About></About>
//             <Constact></Constact> */}
//         </>
//     )
// }


//------------------------------ Navbar ---------------------------------------------------


// const App=()=>{
//     return (
//         <>
//             <NavBar></NavBar>
//             <Switch>
//                 <Route exact path='/' component={About}></Route>
//                 <Route path='/contact' component={Constact}></Route>
//             </Switch>
//             {/* <About></About>
//             <Constact></Constact> */}
//         </>
//     )
// }

//----------------------- useParams ----------------------------------------------------------


// const App=()=>{
//     return (
//         <>
//             <NavBar></NavBar>
//             <Switch>
//                 <Route exact path='/' component={About}></Route>
//                 <Route path='/contact' component={Constact}></Route>
//                 <Route path='/user/:fname' component={User}></Route>
//             </Switch>
//         </>
//     )
// }

//------------------------ card -------------------------------------------

const App = () => {
    return (
        <>
        <h1 className="heading_style">Top Netflix Series</h1>
                        

        {Sdata.map((val)=>{
                return(
                    <Card id={val.id} imgsrc={val.imgsrc} title={val.title} sname={val.sname} link={val.link}></Card>  
                )
            })}

        </>
    )
}



export default App;

