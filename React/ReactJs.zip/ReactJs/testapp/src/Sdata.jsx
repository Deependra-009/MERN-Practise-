import Logo from './Logo.jpg';
const Sdata=[
    {
        id:1,
        sname:"Dark",
        imgsrc:{Logo},
        title:"NetFlix Original Series",
        link:"www.google.com"
    },
    {
        id:2,
        sname:"Dark",
        imgsrc:{Logo},
        title:"NetFlix Original Series",
        link:"www.google.com"
    },
    {
        id:3,
        sname:"Dark",
        imgsrc:{Logo},
        title:"NetFlix Original Series",
        link:"www.google.com"
    },
    {
        id:4,
        sname:"Dark",
        imgsrc:{Logo},
        title:"NetFlix Original Series",
        link:"www.google.com"
    },
    {
        id:5,
        sname:"Dark",
        imgsrc:{Logo},
        title:"NetFlix Original Series",
        link:"www.google.com"
    }
]

export default Sdata;