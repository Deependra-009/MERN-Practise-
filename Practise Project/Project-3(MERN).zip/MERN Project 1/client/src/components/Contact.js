import React from 'react'

function Contact() {
    return (
        <div>
            <h2>contact page</h2>
        </div>
    )
}

export default Contact
